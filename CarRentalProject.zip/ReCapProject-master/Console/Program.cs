﻿using Business.Concrete;
using DataAccess.Concrete;
using DataAccess.Concrete.EntityFramework;
using Entities.Concrete;
using System;

namespace Console
{
    class Program
    {
        static void Main(string[] args)
        {
            //CarTest();
            //BrandTest();
            //ColorTest();
            RentalTest();
            //UserTest();
        }

        

        private static void RentalTest()
        {

            Rental rental = new Rental();
            rental.RentalId =6;
            rental.CarId = 2;
            rental.CustomerId = 3;
            rental.RentDate = DateTime.Now;



            RentalManager rentalManager = new RentalManager(new EfRentalDal());
            //rentalManager.Add(rental);

            var result = rentalManager.GetAll();

            if (result.Success == true)
            {
                foreach (var users in result.Data)
                {
                    System.Console.WriteLine(users.RentalId +  " " + users.RentDate +" "+ users.ReturnDate );
                }
            }
        }

        private static void ColorTest()
        {
            ColorManager colorManager = new ColorManager(new EfColorDal());

            var result1 = colorManager.GetAll();

            if (result1.Success==true)
            {
                foreach (var colors in result1.Data)
                {
                    System.Console.WriteLine(colors.ColorId + " " + colors.ColorName);
                }
            }

            
        }

        private static void BrandTest()
        {
            Brand brand1 = new Brand();
            brand1.BrandId = 8;
            brand1.BrandName = "Tofaş";
            BrandManager brandManager = new BrandManager(new EfBrandDal());
            //brandManager.GetById(3);

            //foreach (var brand in brandManager.GetAll())
            //{
            //    System.Console.WriteLine(brand.BrandId + " " + brand.BrandName);
            //}
        }





        private static void CarTest()
        {
            //Car car1 = new Car();  // Araç ekleme bilgileri
            //car1.CarId = 6;
            //car1.BrandId = 2;
            //car1.ColorId = 3;
            //car1.ModelYear = 2018;
            //car1.DailyPrice = 25000;
            //car1.Description = "Güncellendi";
            //car1.CarName = "V";

            CarManager carManager = new CarManager(new EfCarDal()); //Ekleme,silme,güncelleme
                                                                    // carManager.Add(car1);

            var result = carManager.GetAll();

            if (result.Success==true)
            {
                foreach (var cars in result.Data)  //Listeleme
                {
                    System.Console.WriteLine("Araç İsim= " + cars.CarName);
                    //System.Console.WriteLine("Araç rengi= " + cars.ColorName);
                    //System.Console.WriteLine("Araç Marka= " + cars.BrandName);
                    System.Console.WriteLine("Araç Model Yılı= " + cars.ModelYear);
                    System.Console.WriteLine("Araç Fiyatı= " + cars.DailyPrice);
                    System.Console.WriteLine("Araç Açıklaması= " + cars.Description);
                    System.Console.WriteLine("------------------------------------");
                }
            }
            else
            {
                System.Console.WriteLine(result.Message);  
            }
        }
    }
}
