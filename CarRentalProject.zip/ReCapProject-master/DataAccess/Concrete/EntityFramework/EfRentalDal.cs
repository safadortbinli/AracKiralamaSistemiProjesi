﻿using Core.DataAccess.EntityFramework;
using DataAccess.Abstract;
using Entities.Concrete;
using Entities.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess.Concrete.EntityFramework
{
    public class EfRentalDal : EfEntityRepositoryBase<Rental, ReCapProjectContext>, IRentalDal
    {
        public List<RentalDetailDto> GetRentalDetails()
        {

            using (ReCapProjectContext context = new ReCapProjectContext())
            {
                var result = from r in context.Rentals
                             join ca in context.Cars
                             on r.CarId equals ca.CarId
                             join cu in context.Customers
                             on r.CustomerId equals cu.CustomerId
                             select new RentalDetailDto
                             {
                                CarId=ca.CarId,
                                CustomerId=cu.CustomerId,
                                CarName=ca.CarName,
                                CompanyName = cu.CompanyName,
                                RentDate=r.RentDate,
                                ReturnDate=r.ReturnDate,
                                RentalId=r.RentalId,


                             };
                return result.ToList();
                            
            }         
            
               
        }
    }
}
