﻿using DataAccess.Abstract;
using Entities.Concrete;
using Entities.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace DataAccess.Concrete
{
   public class InMemoryCarDal : ICarDal
    {
        List<Car> _listCar;
        public InMemoryCarDal()
        {
            _listCar = new List<Car> { 
            new Car{CarId=1,BrandId=1,ColorId=1,ModelYear=2020,DailyPrice=175000,Description="sıfır"},
            new Car{CarId=2,BrandId=1,ColorId=1,ModelYear=2015,DailyPrice=80000,Description="Temiz"},
            new Car{CarId=3,BrandId=2,ColorId=3,ModelYear=2018,DailyPrice=110000,Description="hasarlı"},
            new Car{CarId=4,BrandId=2,ColorId=4,ModelYear=2009,DailyPrice=90000,Description="Kazalı"}
            };
        }
        public void Add(Car car)
        {
            _listCar.Add(car);
        }

        public void Delete(Car car)
        {
            Car DeleteCar = _listCar.SingleOrDefault(a=>a.CarId == car.CarId);
            _listCar.Remove(DeleteCar);
        }

        public Car Get(Expression<Func<Car, bool>> filter)
        {
            throw new NotImplementedException();
        }

        public List<Car> GetAll()
        {
            return _listCar;
        }

        public List<Car> GetAll(Expression<Func<Car, bool>> filter = null)
        {
            throw new NotImplementedException();
        }

        public List<Car> GetAllByBrand(int brandId)
        {
            throw new NotImplementedException();
        }

        public List<Color> GetAllByColor(int colorId)
        {
            throw new NotImplementedException();
        }

        public void GetById(Car car)
        {
            throw new NotImplementedException();
        }

        public List<CarDetailDto> GetCarDetails()
        {
            throw new NotImplementedException();
        }

        public void Update(Car car)
        {
            Car UpdateCar = _listCar.SingleOrDefault(a => a.CarId == car.CarId);
            UpdateCar.BrandId = car.BrandId;
            UpdateCar.ColorId = car.ColorId;
            UpdateCar.ModelYear = car.ModelYear;
            UpdateCar.DailyPrice = car.DailyPrice;
            UpdateCar.Description = car.Description;
        }
    }
}
