﻿using Business.Abstract;
using Business.BusinessAspects.Autofac;
using Business.Constants;
using Business.ValidationRules.FluentValidation;
using Core.Aspects.Autofac.Caching;
using Core.Aspects.Autofac.Performance;
using Core.Aspects.Autofac.Transaction;
using Core.Aspects.Autofac.Validation;
using Core.CrossCuttingConcerns.Validation;
using Core.Utilities.Results;
using DataAccess.Abstract;
using Entities.Concrete;
using Entities.DTOs;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Business.Concrete
{
    public class CarManager : ICarService
    {
        ICarDal _cardal;
        public CarManager(ICarDal carDal)
        {
            _cardal = carDal; 
        }

        [SecuredOperation("car.add,admin")]
        [ValidationAspect(typeof(CarValidator))]
        [CacheRemoveAspect("ICarService.Get")]
        public IResult Add(Car car)
        {
            //İş kuralları

           // ValidationTool.Validate(new CarValidator(),car);

            _cardal.Add(car);
             return new SuccessResult(Messages.CarAdded);
        }

        [SecuredOperation("car.delete,admin")]
        public IResult Delete(Car car)
        {
            _cardal.Delete(car);
            return new SuccessResult(Messages.CarDeleted);
        }

        [CacheAspect] // key , value
       // [PerformanceAspect(5)] //Performance testi(5 sn)
        public IDataResult<List<Car>> GetAll()
        {
            //if (DateTime.Now.Hour==15){return new ErrorDataResult<List<Car>>(Messages.SystemRepair);}
            //Thread.Sleep(5000);
            return new SuccessDataResult<List<Car>>(_cardal.GetAll(),Messages.CarListMessage);
        }

        public IDataResult<List<Car>> GetAllByBrandId(int id)
        {
            return new SuccessDataResult<List<Car>>(_cardal.GetAll(p => p.BrandId == id));
        }

        public IDataResult<List<Car>> GetAllByColorId(int id)
        {
            return new SuccessDataResult<List<Car>>(_cardal.GetAll(p=>p.ColorId==id));
        }

        [CacheAspect]
        public IDataResult<Car> GetById(int carId)
        {
            return new SuccessDataResult<Car>(_cardal.Get(c => c.CarId == carId));
        }

        public IDataResult<List<CarDetailDto>> GetCarDetails()
        {
            //if (DateTime.Now.Hour==23)
            //{
            //    return new ErrorDataResult<List<CarDetailDto>>(Messages.SystemRepair);
            //}
            return new SuccessDataResult<List<CarDetailDto>>(_cardal.GetCarDetails());
        }

        public IDataResult<List<Car>> GetUnitPrice(decimal min, decimal max)
        {
            return new SuccessDataResult<List<Car>>(_cardal.GetAll(p=>p.DailyPrice>=min && p.DailyPrice<=max));
        }

        [SecuredOperation("car.update,admin")]
        [CacheRemoveAspect("ICarService.Get")] // ICarService teki getlere uygula.Cache sil.
        public IResult Update(Car car)
        {
            if (car.DailyPrice > 0)
            {
                _cardal.Update(car);
                return new SuccessResult(Messages.CarUpdated);
            }
            return new ErrorResult(Messages.ErrorCarUpdateDailyPriceLimit);
        }

        [TransactionScopeAspect]
        public IResult AddTransactionalTest(Car car)
        {
            _cardal.Update(car);
            _cardal.Add(car);
            return new SuccessResult(Messages.CarUpdated);
        }
    }
}
