﻿using Business.Abstract;
using Business.Constants;
using Business.ValidationRules.FluentValidation;
using Core.Aspects.Autofac.Validation;
using Core.CrossCuttingConcerns.Validation;
using Core.Utilities.Business;
using Core.Utilities.Results;
using DataAccess.Abstract;
using Entities.Concrete;
using Entities.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Concrete
{
   public class RentalManager : IRentalService
    {
        IRentalDal _rentalDal;

        public RentalManager(IRentalDal rentalDal)
        {
            _rentalDal = rentalDal;
         
        }


        [ValidationAspect(typeof(RentalValidator))]
        public IResult Add(Rental rental)
        {
            // if (rental.ReturnDate== null){Console.WriteLine("hata");}
            // ValidationTool.Validate(new RentalValidator(), rental);
            var result = BusinessRules.Run(CheckIfCusmoterRentalCount(rental.CustomerId), CheckIfRentalCarControl(rental.CarId)); //kuralların kontrolü iş motoru

            if (result != null)
            {
                return result;
            }

            _rentalDal.Add(rental);
            return new SuccessResult(Messages.RentalAdded);
        }

        public IResult Delete(Rental rental)
        {
            _rentalDal.Delete(rental);
            return new SuccessResult(Messages.RentalDeleted);
        }

        public IDataResult<List<Rental>> GetAll()
        {
            return new SuccessDataResult<List<Rental>>(_rentalDal.GetAll(),Messages.RentalListMessage);
        }

        public IDataResult<List<Rental>> GetByCarId(int id)
        {
            return new SuccessDataResult<List<Rental>>(_rentalDal.GetAll(r=>r.CarId==id));
        }

        public IDataResult<List<Rental>> GetByCustomerId(int id)
        {
            return new SuccessDataResult<List<Rental>>(_rentalDal.GetAll(r => r.CustomerId == id));
        }

        public IDataResult<Rental> GetById(int rentalId)
        {
            return new SuccessDataResult<Rental>(_rentalDal.Get(r => r.RentalId == rentalId));
        }

        public IDataResult<List<Rental>> GetByRentDate(DateTime firstDate, DateTime FinishDate)
        {
            return new SuccessDataResult<List<Rental>>(_rentalDal.GetAll(r=>r.RentDate>=firstDate && r.RentDate<=FinishDate)) ;
        }

        public IDataResult<List<RentalDetailDto>> GetRentalDetails()
        {
            if (DateTime.Now.Hour == 23)
            {
                return new ErrorDataResult<List<RentalDetailDto>>(Messages.SystemRepair); // MaintenanceTime:bakım zamanı anlamına gelir.Generate ettik
            }
            return new SuccessDataResult<List<RentalDetailDto>>(_rentalDal.GetRentalDetails()) ;
        }

        public IResult Update(Rental rental)
        {
            _rentalDal.Update(rental);
            return new SuccessResult(Messages.RentalUpdated);
        }
      private IResult CheckIfCusmoterRentalCount(int customerId) //Aynı müşteri en fazla 5 araç kiralayabilir. // kuralı
        {
            var result = _rentalDal.GetAll(c => c.CustomerId == customerId).Count;

            if (result > 5)
            {
                return new ErrorResult(Messages.CusmoterRentalCountError);
            }
            return new SuccessResult();
        }

        private IResult CheckIfRentalCarControl(int carId)
        {
            var result = _rentalDal.GetAll(ca=> ca.CarId == carId).Count;

            if (result>=1)
            {
                return new ErrorResult(Messages.RentalSameCarError);
            }
            return new SuccessResult();
        }
    }
}
