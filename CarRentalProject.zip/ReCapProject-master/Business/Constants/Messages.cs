﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Business.Constants
{
    public static class Messages
    {
        //Public 
        public static string SystemRepair = "Sistem bakımda.Daha sonra tekrar deneyiniz.";

        //Car
        public static string CarAdded = "Araç Eklendi.";
        public static string CarDeleted = "Araç Silindi.";
        public static string CarUpdated = "Araç Güncellendi.";
        public static string CarNameWarn = "Araç İsimi en az iki karakter olmalıdır.";
        public static string CarListMessage = "Araçlar listelendi.";

        //Brand
        public static string BrandAdded = "Marka Eklendi.";
        public static string BrandDeleted = "Marka Silindi.";
        public static string BrandUpdated = "Marka Güncellendi.";
        public static string BrandListMessage = "Markalar listelendi.";

        //Color
        public static string ColorAdded = "Renk Eklendi.";
        public static string ColorDeleted = "Renk Silindi.";
        public static string ColorUpdated = "Renk Güncellendi.";
        public static string ColorListMessage = "Renkler listelendi.";

        // User
        public static string UserAdded = "Kullanıcı Eklendi.";
        public static string UserDeleted = "Kullanıcı Silindi.";
        public static string UserUpdated = "Kullanıcı Güncellendi.";
        public static string UserListMessage = "Kullanıcılar listelendi.";

        // Customer
        public static string CustomerAdded = "Müşteri Eklendi.";
        public static string CustomerDeleted = "Müşteri Silindi.";
        public static string CustomerUpdated = "Müşteri Güncellendi.";
        public static string CustomerListMessage = "Müşteriler listelendi.";

        //Rental
        public static string RentalAdded = "Araç, Kiralananlar listesine Eklendi.";
        public static string RentalDeleted = "Araç, kiralananlar listesinden Silindi.";
        public static string RentalUpdated = "Kiralama detayları Güncellendi.";
        public static string RentalListMessage = "Kiralanan araçlar listelendi.";
        public static string CusmoterRentalCountError = "Bir müşteri en fazla 5 araç kiralayabilir.";
        public static string RentalSameCarError = "Bu araç kiralanmıştır.Lütfen başka bir araç kiralayınız.";

        //CarImages
        public static string CarImageAdded = "Araca resim eklendi.";
        public static string CarImageDeleted = "Aracın resimi silindi.";
        public static string CarImageUptaded = "Aracın resimi güncellendi.";
        public static string CarImageCountControl = "Araca en fazla 5 görsel ekleyebilirsiniz.";
        public static string AuthorizationDenied = "Yetkiniz yok.";

        //User Giriş kayıt olayları
        public static string UserRegistered = "Kayıt oldu.";
        public static string UserNotFound = "Kullanıcı Bulunamadı.";
        public static string PasswordError = "Parola Hatası";
        public static string SuccessfulLogin = "Başarılı giriş";
        public static string UserAlreadyExists = "Kullanıcı Mevcut";
        public static string AccessTokenCreated = "Token Oluşturuldu.";
        public static string ErrorCarUpdateDailyPriceLimit = "Kiralama Ücreti 0'dan büyük olmalı.";
    }
}
