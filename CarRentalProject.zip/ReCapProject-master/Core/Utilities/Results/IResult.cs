﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Utilities.Results
{
    public interface IResult
    {
        bool Success { get; } // İşlem başarılı mı?,başarısız mı? True,False döndürür.
        string Message { get; }//Kullanıcıya mesaj döndürür

    }
}
